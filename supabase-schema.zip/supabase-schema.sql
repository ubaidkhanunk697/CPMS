-- ==============================================================================
-- Clinic Payment Management System - Complete Supabase PostgreSQL Schema
-- Includes: Tables, Constraints, Row Level Security (RLS) Policies, Triggers & Seeds
-- ==============================================================================

-- 1. EXTENSIONS
create extension if not exists "uuid-ossp";

-- ==============================================================================
-- 2. TABLES
-- ==============================================================================

-- 2.1 Staff Profiles Table (Linked to auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  username text not null unique,
  full_name text not null,
  role text not null check (role in ('mri_officer', 'investigation_officer', 'operation_officer', 'doctor')),
  office text not null check (office in ('mri', 'investigation', 'operation', 'doctor')),
  initials text not null,
  accent_color text default '#1E293B',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2.2 MRI Payments Table
-- Note: MRI Office Share and Doctor Amount are derived via centralized CalculationEngine 
-- to prevent duplicate/conflicting totals in the database.
create table if not exists public.mri_payments (
  id uuid primary key default gen_random_uuid(),
  patient_name text not null,
  mri_type text not null,
  payment_amount numeric(12, 2) not null check (payment_amount > 0),
  date date not null default current_date,
  day text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) default auth.uid()
);

-- 2.3 Investigation Payments Table (100% Doctor Amount)
create table if not exists public.investigation_payments (
  id uuid primary key default gen_random_uuid(),
  patient_name text not null,
  test_name text not null,
  payment_amount numeric(12, 2) not null check (payment_amount > 0),
  date date not null default current_date,
  day text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) default auth.uid()
);

-- 2.4 Operation / Assistant Payments Table (100% Doctor Amount)
create table if not exists public.operation_payments (
  id uuid primary key default gen_random_uuid(),
  patient_name text not null,
  operation_name text not null,
  payment_amount numeric(12, 2) not null check (payment_amount > 0),
  date date not null default current_date,
  day text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references auth.users(id) default auth.uid()
);

-- Indexes for optimal date-range querying
create index if not exists idx_mri_payments_date on public.mri_payments(date desc, created_at desc);
create index if not exists idx_inv_payments_date on public.investigation_payments(date desc, created_at desc);
create index if not exists idx_op_payments_date on public.operation_payments(date desc, created_at desc);

-- ==============================================================================
-- 3. SECURITY DEFINER HELPER FUNCTIONS FOR RLS
-- ==============================================================================

-- Returns the authenticated user's role from public.profiles
create or replace function public.get_current_user_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Returns the authenticated user's assigned office from public.profiles
create or replace function public.get_current_user_office()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select office from public.profiles where id = auth.uid();
$$;

-- ==============================================================================
-- 4. ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

-- 4.1 Enable RLS on all tables
alter table public.profiles enable row level security;
alter table public.mri_payments enable row level security;
alter table public.investigation_payments enable row level security;
alter table public.operation_payments enable row level security;

-- 4.2 Profiles Policies
-- All authenticated users can view staff profiles
create policy "Allow authenticated users to read profiles"
  on public.profiles
  for select
  to authenticated
  using (true);

-- Users can only update their own profile
create policy "Allow users to update own profile"
  on public.profiles
  for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- 4.3 MRI Payments Policies
-- MRI Officer and Doctor can read MRI payments
create policy "MRI Read: MRI Officer and Doctor"
  on public.mri_payments
  for select
  to authenticated
  using (
    public.get_current_user_role() in ('mri_officer', 'doctor')
  );

-- MRI Officer can insert MRI payments
create policy "MRI Insert: MRI Officer only"
  on public.mri_payments
  for insert
  to authenticated
  with check (
    public.get_current_user_role() = 'mri_officer'
  );

-- MRI Officer can update MRI payments
create policy "MRI Update: MRI Officer only"
  on public.mri_payments
  for update
  to authenticated
  using (
    public.get_current_user_role() = 'mri_officer'
  )
  with check (
    public.get_current_user_role() = 'mri_officer'
  );

-- MRI Officer and Doctor can delete MRI payments (e.g. single delete or Clear All)
create policy "MRI Delete: MRI Officer and Doctor"
  on public.mri_payments
  for delete
  to authenticated
  using (
    public.get_current_user_role() in ('mri_officer', 'doctor')
  );

-- 4.4 Investigation Payments Policies
-- Investigation Officer and Doctor can read Investigation payments
create policy "Investigation Read: Investigation Officer and Doctor"
  on public.investigation_payments
  for select
  to authenticated
  using (
    public.get_current_user_role() in ('investigation_officer', 'doctor')
  );

-- Investigation Officer can insert Investigation payments
create policy "Investigation Insert: Investigation Officer only"
  on public.investigation_payments
  for insert
  to authenticated
  with check (
    public.get_current_user_role() = 'investigation_officer'
  );

-- Investigation Officer can update Investigation payments
create policy "Investigation Update: Investigation Officer only"
  on public.investigation_payments
  for update
  to authenticated
  using (
    public.get_current_user_role() = 'investigation_officer'
  )
  with check (
    public.get_current_user_role() = 'investigation_officer'
  );

-- Investigation Officer and Doctor can delete Investigation payments
create policy "Investigation Delete: Investigation Officer and Doctor"
  on public.investigation_payments
  for delete
  to authenticated
  using (
    public.get_current_user_role() in ('investigation_officer', 'doctor')
  );

-- 4.5 Operation Payments Policies
-- Operation Officer and Doctor can read Operation payments
create policy "Operation Read: Operation Officer and Doctor"
  on public.operation_payments
  for select
  to authenticated
  using (
    public.get_current_user_role() in ('operation_officer', 'doctor')
  );

-- Operation Officer can insert Operation payments
create policy "Operation Insert: Operation Officer only"
  on public.operation_payments
  for insert
  to authenticated
  with check (
    public.get_current_user_role() = 'operation_officer'
  );

-- Operation Officer can update Operation payments
create policy "Operation Update: Operation Officer only"
  on public.operation_payments
  for update
  to authenticated
  using (
    public.get_current_user_role() = 'operation_officer'
  )
  with check (
    public.get_current_user_role() = 'operation_officer'
  );

-- Operation Officer and Doctor can delete Operation payments
create policy "Operation Delete: Operation Officer and Doctor"
  on public.operation_payments
  for delete
  to authenticated
  using (
    public.get_current_user_role() in ('operation_officer', 'doctor')
  );

-- ==============================================================================
-- 5. TRIGGERS FOR AUTO-UPDATING TIMESTAMPS
-- ==============================================================================

create or replace function public.trigger_set_timestamp()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger set_timestamp_profiles
  before update on public.profiles
  for each row execute procedure public.trigger_set_timestamp();

create trigger set_timestamp_mri
  before update on public.mri_payments
  for each row execute procedure public.trigger_set_timestamp();

create trigger set_timestamp_inv
  before update on public.investigation_payments
  for each row execute procedure public.trigger_set_timestamp();

create trigger set_timestamp_op
  before update on public.operation_payments
  for each row execute procedure public.trigger_set_timestamp();

-- ==============================================================================
-- 6. TRIGGER FOR AUTOMATIC PROFILE SYNC ON USER CREATION (auth.users)
-- ==============================================================================

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, username, full_name, role, office, initials, accent_color)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', 'Clinic Staff'),
    coalesce(new.raw_user_meta_data->>'role', 'mri_officer'),
    coalesce(new.raw_user_meta_data->>'office', 'mri'),
    coalesce(new.raw_user_meta_data->>'initials', 'CP'),
    coalesce(new.raw_user_meta_data->>'accent_color', '#1E293B')
  )
  on conflict (id) do update set
    email = excluded.email,
    full_name = excluded.full_name,
    role = excluded.role,
    office = excluded.office;
  return new;
end;
$$ language plpgsql security definer;

-- Drop trigger if exists and recreate
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ==============================================================================
-- 7. SEED DATA & MOCK USER SCRIPT (Run in Supabase SQL Editor if needed)
-- ==============================================================================

/*
-- To create the 4 clinic users in Supabase Auth, use Supabase Dashboard > Authentication > Users > Add User, 
-- or execute SQL using auth.users insertion with metadata:

-- 1. Aqeb Khan (MRI Officer)
-- Email: aqeb@clinic.local
-- Raw User Meta Data: {"username":"aqeb","full_name":"Aqeb Khan","role":"mri_officer","office":"mri","initials":"AK","accent_color":"#EF4444"}

-- 2. Shezaad (Investigation Officer)
-- Email: shezaad@clinic.local
-- Raw User Meta Data: {"username":"shezaad","full_name":"Shezaad","role":"investigation_officer","office":"investigation","initials":"SH","accent_color":"#0284C7"}

-- 3. Qari Mustajab (Operation Officer)
-- Email: mustajab@clinic.local
-- Raw User Meta Data: {"username":"mustajab","full_name":"Qari Mustajab","role":"operation_officer","office":"operation","initials":"QM","accent_color":"#D97706"}

-- 4. Dr. Nawaz Khattak (Doctor)
-- Email: doctor@clinic.local
-- Raw User Meta Data: {"username":"doctor","full_name":"Dr. Nawaz Khattak","role":"doctor","office":"doctor","initials":"NK","accent_color":"#0F172A"}
*/
